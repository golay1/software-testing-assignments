package Homework4;

public enum Problem2ClassStatus {NorthernHemisphere,SouthernHemisphere}