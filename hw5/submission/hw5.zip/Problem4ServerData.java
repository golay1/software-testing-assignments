package Homework5;

public interface Problem4ServerData {

	public int getMemberPoints();
}